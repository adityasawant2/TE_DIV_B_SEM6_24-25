from flask import Flask, render_template, request, jsonify, Response, redirect, url_for, session, g
import numpy as np
import os
import cv2
import time
import threading
import mysql.connector
from mysql.connector import Error
from modules.video_processing import process_frame, parking_slots, threshold
from modules.admin_utils import reset_parking_slots, get_all_bookings

app = Flask(__name__)

# Remove the global db connection and use per-request connections
dbconfig = {
    "host": "localhost",         # Change if needed
    "user": "root",              # Replace with your MySQL username
    "password": "Adi24568$9",
    "port": "3306",
    "database": "parking_slot_detection"
}

app.secret_key = os.getenv('FLASK_SECRET_KEY', 'default_fallback_key')

save_path = "parking_slots.npy"

# In-memory user storage (for reference; not used for authentication)
users = {}

# Bookings: mapping slot_id (int) -> { "customer": str, "phone": str, "start_time": float, "occupied": bool, "edited": bool, "rate": float }
bookings = {}

# Global payments list; each entry: { "slot": int, "customer": str, "phone": str, "duration": float, "cost": float, "rate": float }
remaining_payments = []

empty_since = {}

def get_db():
    """
    Get a database connection for the current request.
    """
    if 'db' not in g:
        try:
            g.db = mysql.connector.connect(**dbconfig)
        except Error as e:
            app.logger.error(f"Error connecting to MySQL: {e}")
            g.db = None
    return g.db

@app.teardown_appcontext
def close_db(exception):
    """
    Close the database connection after each request.
    """
    db = g.pop('db', None)
    if db is not None and db.is_connected():
        db.close()

def get_demand_info():
    status = app.config.get('PARKING_STATUS', {})
    total = len(status)
    if total == 0:
        return {"demand": "Low", "multiplier": 0.4}
    occupied = sum(1 for s in status.values() if s in ["booked", "occupied"])
    ratio = occupied / total
    if ratio < 0.3:
        return {"demand": "Low", "multiplier": 0.4}
    elif ratio > 0.7:
        return {"demand": "High", "multiplier": 1.5}
    else:
        multiplier = 0.4 + ((ratio - 0.3) / (0.7 - 0.3)) * (1.5 - 0.4)
        return {"demand": "Medium", "multiplier": round(multiplier, 2)}

def generate_frames():
    while True:
        frame, status = process_frame(bookings)
        app.config['PARKING_STATUS'] = status
        ret, buffer = cv2.imencode('.jpg', frame)
        yield (b'--frame\r\n'
               b'Content-Type: image/jpeg\r\n\r\n' + buffer.tobytes() + b'\r\n')

def monitor_empty_slots():
    global empty_since, bookings, remaining_payments
    while True:
        status = app.config.get('PARKING_STATUS', {})
        now = time.time()
        for slot in list(status.keys()):
            if status[slot] == "empty":
                if slot in bookings and bookings[slot].get("occupied", False):
                    if slot not in empty_since:
                        empty_since[slot] = now
                    elif now - empty_since[slot] >= 5:
                        booking = bookings[slot]
                        duration_sec = now - booking["start_time"]
                        duration = round(duration_sec / 60, 2)
                        cost = round(duration_sec * (booking["rate"] / 60), 2)
                        remaining_payments.append({
                            "slot": slot,
                            "customer": booking["customer"],
                            "phone": booking["phone"],
                            "duration": duration,
                            "cost": cost,
                            "rate": booking["rate"]
                        })
                        del bookings[slot]
                        del empty_since[slot]
                else:
                    empty_since.pop(slot, None)
            else:
                empty_since.pop(slot, None)
        time.sleep(1)

threading.Thread(target=monitor_empty_slots, daemon=True).start()

# --- Authentication Routes ---
@app.route('/login', methods=['GET', 'POST'])
def auth():
    message = ""
    if request.method == "POST":
        username = request.form.get("username")
        password = request.form.get("password")
        db = get_db()
        if db is None:
            return "Database connection error", 500
        cursor = db.cursor()
        # Retrieve username, phone, password, and role
        cursor.execute("SELECT username, phone, password, role FROM users WHERE username = %s", (username,))
        user = cursor.fetchone()
        cursor.close()
        if not user:
            message = "User does not exist"
            return render_template("auth.html", message=message)
        elif user[2] != password:
            message = "Password does not match..!"
            return render_template("auth.html", message=message)
        else:
            # Store role and user_phone in session
            session['role'] = user[3]
            session['user_phone'] = user[1]
            if user[3] == 'admin':
                return redirect(url_for("admin"))
            else:
                return redirect(url_for("dashboard"))
    return render_template("auth.html", message=message)

@app.route('/register', methods=['GET', 'POST'])
def register():
    message = ""
    if request.method == "POST":
        username = request.form.get("username")
        phone = request.form.get("phone")
        password = request.form.get("password")
        db = get_db()
        if db is None:
            return "Database connection error", 500
        cursor = db.cursor()
        cursor.execute("SELECT username FROM users WHERE username = %s", (username,))
        user = cursor.fetchone()
        if user:
            message = "User already exists!"
        else:
            cursor.execute(
                "INSERT INTO users (username, phone, password, role) VALUES (%s, %s, %s, 'user')",
                (username, phone, password)
            )
            db.commit()
            message = "Account successfully registered!"
        cursor.close()
    return render_template("auth.html", message=message)

@app.route('/logout')
def logout():
    session.pop('role', None)
    session.pop('user_phone', None)
    return redirect(url_for('auth'))

# --- Default Route ---
@app.route('/')
def home():
    return render_template("auth.html")

# --- Dashboard for Non-Admin Users ---
@app.route('/dashboard')
def dashboard():
    if not session.get('role') or session.get('role') == "admin":
        return redirect(url_for('/'))
    return render_template('index.html')

@app.route('/admin')
def admin():
    if not session.get('role') or session.get('role') != "admin":
        return redirect(url_for('/'))
    return render_template('admin.html')

# --- Video Feed ---
@app.route('/video_feed')
def video_feed():
    return Response(generate_frames(), mimetype='multipart/x-mixed-replace; boundary=frame')

# --- Slot Management ---
@app.route('/mark_slots', methods=['POST'])
def mark_slots_route():
    global parking_slots
    data = request.json
    new_slots = data['slots']  # Each slot is a list of 4 relative points.
    if os.path.exists(save_path) and os.path.getsize(save_path) > 0:
        try:
            existing_slots = np.load(save_path, allow_pickle=True).tolist()
        except Exception:
            existing_slots = []
    else:
        existing_slots = []
    merged_slots = existing_slots + new_slots
    np.save(save_path, merged_slots)
    parking_slots.clear()
    parking_slots.extend(merged_slots)
    return jsonify({"message": "Slots updated successfully!"})

# --- Booking Endpoints ---
@app.route('/book_slot', methods=['POST'])
def book_slot():
    global bookings
    data = request.json
    slot_id = int(data['slot_id'])
    status = app.config.get('PARKING_STATUS', {})
    user_phone = session.get('user_phone')
    if slot_id in status and status[slot_id] == "empty":
        rate = get_demand_info()["multiplier"]
        bookings[slot_id] = {
            "customer": data['customer'],
            "phone": user_phone,
            "start_time": time.time(),
            "occupied": False,
            "edited": False,
            "rate": rate
        }
        return jsonify({"message": f"Slot {slot_id} booked for {data['customer']}!"})
    return jsonify({"error": "Slot is not available for booking."}), 400

@app.route('/edit_booking', methods=['POST'])
def edit_booking():
    global bookings
    data = request.json
    slot_id = int(data['slot_id'])
    new_customer = data.get('customer')
    new_phone = data.get('phone')
    if slot_id in bookings:
        # Update only the name and phone number; preserve start_time and rate
        bookings[slot_id]["customer"] = new_customer
        bookings[slot_id]["phone"] = new_phone
        bookings[slot_id]["edited"] = True
        return jsonify({"message": f"Booking for slot {slot_id} updated!"})
    else:
        rate = get_demand_info()["multiplier"]
        bookings[slot_id] = {
            "customer": new_customer,
            "phone": new_phone,
            "start_time": time.time(),
            "occupied": False,
            "edited": True,
            "rate": rate
        }
        return jsonify({"message": f"Booking for slot {slot_id} created and updated!"})

@app.route('/get_status', methods=['GET'])
def get_status():
    return jsonify(app.config.get('PARKING_STATUS', {}))

@app.route('/clear_bookings', methods=['POST'])
def clear_bookings():
    global bookings
    bookings.clear()
    return jsonify({"message": "All bookings cleared!"})

@app.route('/reset_slots', methods=['POST'])
def reset_slots():
    resp = reset_parking_slots()
    parking_slots.clear()
    bookings.clear()
    remaining_payments.clear()
    return jsonify(resp)

@app.route('/all_bookings', methods=['GET'])
def all_bookings():
    status = app.config.get('PARKING_STATUS', {})
    result = {}
    for slot, stat in status.items():
        if stat in ["booked", "occupied"]:
            if slot in bookings:
                booking = bookings[slot]
                duration_sec = time.time() - booking["start_time"]
                duration = round(duration_sec / 60, 2)
                cost = round(duration_sec * (booking["rate"] / 60), 2)
                result[slot] = {
                    "customer": booking["customer"],
                    "phone": booking["phone"],
                    "duration": duration,
                    "rate": booking["rate"],
                    "cost": cost
                }
            else:
                result[slot] = {"customer": "Occupied", "phone": "N/A", "duration": 0, "rate": 0, "cost": 0}
    return jsonify(result)

@app.route('/remaining_payments', methods=['GET'])
def remaining_payments_route():
    return jsonify(remaining_payments)

@app.route('/clear_payments', methods=['POST'])
def clear_payments():
    global remaining_payments
    remaining_payments.clear()
    return jsonify({"message": "Remaining payments cleared!"})

@app.route('/remove_payment', methods=['POST'])
def remove_payment():
    global remaining_payments
    data = request.json
    slot = data.get("slot")
    for idx, payment in enumerate(remaining_payments):
        if payment["slot"] == slot:
            removed = remaining_payments.pop(idx)
            return jsonify({"message": f"Removed payment for slot {removed['slot']}."})
    return jsonify({"error": "Payment not found."}), 404

@app.route('/demand_info', methods=['GET'])
def demand_info():
    info = get_demand_info()
    return jsonify(info)

# --- User-Specific Endpoints ---
@app.route('/my_bookings', methods=['GET'])
def my_bookings():
    if not session.get('user_phone') or session.get('role') == 'admin':
        return jsonify({"error": "Unauthorized"}), 401
    user_phone = session.get('user_phone')
    result = {}
    for slot, booking in bookings.items():
        if booking["phone"] == user_phone:
            duration_sec = time.time() - booking["start_time"]
            duration = round(duration_sec / 60, 2)
            cost = round(duration_sec * (booking["rate"] / 60), 2)
            result[slot] = {
                "duration": duration,
                "rate": booking["rate"],
                "cost": cost,
                "occupied": booking.get("occupied", False)
            }
    return jsonify(result)

@app.route('/cancel_booking', methods=['POST'])
def cancel_booking():
    if not session.get('user_phone') or session.get('role') == 'admin':
        return jsonify({"error": "Unauthorized"}), 401
    data = request.json
    slot_id = int(data.get('slot_id'))
    user_phone = session.get('user_phone')
    if slot_id in bookings and bookings[slot_id]['phone'] == user_phone:
        # Capture a fresh frame from the video to directly check the slot's status
        video_path = "static/parking_video.mp4"
        cap = cv2.VideoCapture(video_path)
        ret, frame = cap.read()
        if not ret:
            cap.set(cv2.CAP_PROP_POS_FRAMES, 0)
            ret, frame = cap.read()
        cap.release()
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        _, binary = cv2.threshold(gray, 150, 255, cv2.THRESH_BINARY)
        if slot_id - 1 < len(parking_slots):
            pts = parking_slots[slot_id - 1]
            frame_h, frame_w = frame.shape[:2]
            abs_pts = [[int(pt[0] * frame_w), int(pt[1] * frame_h)] for pt in pts]
            pts_array = np.array(abs_pts, np.int32)
            x, y, w, h = cv2.boundingRect(pts_array)
            crop = binary[y:y+h, x:x+w]
            count = cv2.countNonZero(crop)
            print(f"DEBUG: Slot {slot_id} nonzero count = {count} (threshold = {threshold})")
            if count < threshold:
                booking = bookings[slot_id]
                duration_sec = time.time() - booking["start_time"]
                cost = round(duration_sec * (booking["rate"] / 60), 2)
                if cost > 10:
                    remaining_payments.append({
                        "slot": slot_id,
                        "customer": booking["customer"],
                        "phone": booking["phone"],
                        "duration": round(duration_sec / 60, 2),
                        "cost": cost,
                        "rate": booking["rate"]
                    })
                del bookings[slot_id]
                return jsonify({"message": f"Booking for slot {slot_id} cancelled."})
            else:
                return jsonify({"error": "Cannot cancel booking, a car is present in the slot."}), 400
        else:
            return jsonify({"error": "Slot coordinates not found."}), 404
    return jsonify({"error": "Booking not found for your account."}), 404

@app.route('/my_payments', methods=['GET'])
def my_payments():
    if not session.get('user_phone') or session.get('role') == 'admin':
        return jsonify({"error": "Unauthorized"}), 401
    user_phone = session.get('user_phone')
    user_payments = [p for p in remaining_payments if p["phone"] == user_phone]
    return jsonify(user_payments)

if __name__ == "__main__":
    print("✅ Running Flask on http://127.0.0.1:5000/")
    app.run(debug=True)