import cv2
import numpy as np
import os
import time
from modules.admin_utils import get_all_bookings  # if needed

video_path = "static/parking_video.mp4"
threshold = 30

# Open a persistent video capture.
cap = cv2.VideoCapture(video_path)

# Load parking slots (stored as relative coordinates).
if os.path.exists("parking_slots.npy") and os.path.getsize("parking_slots.npy") > 0:
    try:
        parking_slots = np.load("parking_slots.npy", allow_pickle=True).tolist()
    except Exception as e:
        print(f"Error loading parking_slots.npy: {e}")
        parking_slots = []
else:
    parking_slots = []

def is_proper_booking(booking):
    """Return True if booking has proper details (non-default)."""
    return booking.get("customer") not in ["Unknown"] and booking.get("phone") not in ["N/A"]

def process_frame(bookings):
    global cap, parking_slots, video_path

    if not cap.isOpened():
        cap = cv2.VideoCapture(video_path)
    
    ret, frame = cap.read()
    if not ret or frame is None:
        cap.set(cv2.CAP_PROP_POS_FRAMES, 0)
        ret, frame = cap.read()
    if frame is None:
        frame = np.zeros((360, 640, 3), dtype=np.uint8)
        cv2.putText(frame, "Video feed not available", (50, 180),
                    cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 255), 2)
        return frame, {}
    
    frame_h, frame_w = frame.shape[:2]
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    _, binary = cv2.threshold(gray, 150, 255, cv2.THRESH_BINARY)
    status = {}
    demand_info = None
    
    for idx, slot in enumerate(parking_slots):
        abs_pts = [[int(pt[0] * frame_w), int(pt[1] * frame_h)] for pt in slot]
        pts = np.array(abs_pts, np.int32)
        if pts.shape[0] < 4:
            continue
        x, y, w, h = cv2.boundingRect(pts)
        crop = binary[y:y+h, x:x+w]
        count = cv2.countNonZero(crop)
        slot_id = idx + 1
        
        if count < threshold:
            # No car detected
            if slot_id in bookings:
                if bookings[slot_id].get("occupied", False):
                    status[slot_id] = "empty"
                    color = (0, 255, 0)  # Green for vacant
                else:
                    status[slot_id] = "booked"
                    if is_proper_booking(bookings[slot_id]):
                        color = (255, 0, 0)  # Blue if proper booking details provided
                    else:
                        color = (0, 0, 255)  # Red if details missing
            else:
                status[slot_id] = "empty"
                color = (0, 255, 0)
        else:
            # Car is present
            if slot_id in bookings:
                bookings[slot_id]["occupied"] = True
                status[slot_id] = "booked"
                if is_proper_booking(bookings[slot_id]):
                    color = (255, 0, 0)  # Blue if proper booking details provided
                else:
                    color = (0, 0, 255)  # Red if details missing
            else:
                # Unregistered car detected; auto-create booking with default details
                demand_info = demand_info or __import__('__main__').get_demand_info()
                bookings[slot_id] = {
                    "customer": "Unknown",
                    "phone": "N/A",
                    "start_time": time.time(),
                    "occupied": True,
                    "edited": False,
                    "rate": demand_info["multiplier"]
                }
                status[slot_id] = "booked"
                color = (0, 0, 255)  # Red for unregistered vehicles
        
        cv2.polylines(frame, [pts], isClosed=True, color=color, thickness=2)
        cv2.putText(frame, f"Slot {slot_id}", (pts[0][0], pts[0][1] - 5),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 2)
    
    time.sleep(0.1)
    return frame, status