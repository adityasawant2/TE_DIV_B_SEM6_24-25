import os
import numpy as np

save_path = "parking_slots.npy"

def reset_parking_slots():
    if os.path.exists(save_path):
        os.remove(save_path)
        return {"message": "Parking slots reset successfully!"}
    return {"error": "No parking slots found to reset."}

def get_all_bookings(bookings):
    if not bookings:
        return {"message": "No active bookings."}
    return bookings